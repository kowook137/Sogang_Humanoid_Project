import argparse
from pathlib import Path

import torch
from datasets import load_dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from trl import SFTConfig, SFTTrainer

MODULE_DIR = Path(__file__).resolve().parent


def parse_args():
    parser = argparse.ArgumentParser(description="EXAONE 4.0 Gyeongsang QLoRA training")
    parser.add_argument("--model-id", default="LGAI-EXAONE/EXAONE-4.0-1.2B")
    parser.add_argument(
        "--train-file",
        type=Path,
        default=MODULE_DIR / "data" / "processed" / "gyeongsang" / "lora_v1" / "train.jsonl",
    )
    parser.add_argument(
        "--output-dir", type=Path, default=MODULE_DIR / "outputs" / "exaone-gyeongsang-lora-v1"
    )
    parser.add_argument("--epochs", type=float, default=1.0)
    return parser.parse_args()


args = parse_args()
model_id = args.model_id
output_dir = str(args.output_dir)

# 2. 모델 및 토크나이저 로드
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_use_double_quant=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.float16
)

tokenizer = AutoTokenizer.from_pretrained(model_id)
tokenizer.pad_token = tokenizer.eos_token
tokenizer.padding_side = "right"

model = AutoModelForCausalLM.from_pretrained(
    model_id,
    quantization_config=bnb_config,
    device_map="auto",
    torch_dtype=torch.float16,
    trust_remote_code=True
)

# 3. LoRA 설정
model = prepare_model_for_kbit_training(model)
lora_config = LoraConfig(
    r=16,
    lora_alpha=32,
    target_modules="all-linear", 
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM"
)
model = get_peft_model(model, lora_config)

# 4. 데이터셋 로드 및 Chat Template 포맷팅
if not args.train_file.is_file():
    raise FileNotFoundError(
        f"학습 파일이 없습니다: {args.train_file}\n"
        "먼저 build_gyeongsang_lora_dataset.py를 실행하세요."
    )
dataset = load_dataset("json", data_files=str(args.train_file), split="train")

# 5. 트레이너 설정
training_args = SFTConfig(
    output_dir=output_dir,
    per_device_train_batch_size=2,
    gradient_accumulation_steps=8,
    learning_rate=1e-4,
    fp16=True,
    logging_steps=10,
    num_train_epochs=args.epochs,
    save_strategy="steps",
    save_steps=100,
    optim="paged_adamw_8bit",
    remove_unused_columns=False,
    max_length=2048,
    report_to="none",
)

trainer = SFTTrainer(
    model=model,
    train_dataset=dataset,
    args=training_args,
    processing_class=tokenizer,
)

# 6. 학습 및 저장
trainer.train()
trainer.model.save_pretrained(output_dir)
tokenizer.save_pretrained(output_dir)
